// package lab4; 
// import java.util.Scanner; 
// import java.util.*; 
// import java.util.HashMap;

// public class Lab4 {

//     private static double classAverage = 0; 

//     public static void main (String [] args) {  

//         ArrayList <Student> studentList = new ArrayList<Student>(); 
//         HashMap <String, Student > mapStudent = new HashMap <String, Student> (); 

//         Scanner input = new Scanner (System.in); 
//         boolean notEnd = true; 
//         Search searchHash = new Search(); 

//         while (notEnd == true)  { 
//             System.out.println(); 
//             menu(); //print menu/option to proceed in program 
//             String command = input.nextLine(); 
//             if (command.equalsIgnoreCase("1")) { //user wants to add a student to the list 
//                 addStudent(studentList, mapStudent);
//                 searchHash.addToHashMap(mapStudent, studentList);  //add key and value to HashMap
//             }
//             if (command.equalsIgnoreCase("2")) { //user wants to add a student to the list 
//                 addGradStudent(studentList,mapStudent);
//                 searchHash.addToHashMap(mapStudent, studentList); //add key and value to HashMap
//             }
//             if(command.equalsIgnoreCase("3"))  { //user wants to print all student in the list
//                 printList(studentList);
//             }
//             if (command.equalsIgnoreCase("4")) { //user wants to print the Class Average and No. of students
//                 classAverage(studentList); 
//             }
//             if (command.equalsIgnoreCase("5")) { //user wants to perform a search in studentList
//                 Search search = new Search (); 
//                 search.searchByProgram(studentList); //search for program in studentList and output it
//             } 
//             if (command.equalsIgnoreCase("6")) { //user wants to load students from a file to arrayList
//                 FileIO loadFileIO = new FileIO (); 
//                 loadFileIO.loadFile(studentList, mapStudent);
//                 //searchHash.addToHashMapforFile(mapStudent, studentList); // add key and value to HashMap
//             } 
//             if (command.equalsIgnoreCase("7")) { //user wants to save students to a file
//                 FileIO writeFileIO = new FileIO (); 
//                 writeFileIO.saveFile(studentList);
//             } 
//             if (command.equalsIgnoreCase("8")) { //user search Via HashMap
//                 searchHash.searchByHashMaps(mapStudent); //search Via HashMap
//             }     
//             if (command.equalsIgnoreCase("9")) {
//                 notEnd = false;
//             } // user wants to exit
//         }
//     }
//     /**
//      * prints menu
//      */
//     public static void menu () { 
//         System.out.println("(1) Enter information for a new student"); 
//         System.out.println("(2) Enter information for a new Graduate Student"); 
//         System.out.println("(3) Show all student information with each attribute on a separate line"); 
//         System.out.println("(4) Print the average of the average grades for class, as well as the total number of students"); 
//         System.out.println("(5) Enter a specific program and show all student information for that program"); 
//         System.out.println("(6) Load student information from an input file"); 
//         System.out.println("(7) Save all student information to an output file"); 
//         System.out.println("(8) Lookup via HashMap with program, year, and lastName"); 
//         System.out.println("(9) End program."); 
//         System.out.println("\n"); 
//         System.out.print("Enter a command: "); 
//     }
//     /**
//      * create new GraduateStdent and add to studentList
//      * @param studentList 
//      */
//     public static void addGradStudent (ArrayList <Student> studentList, HashMap <String, Student> mapStudent) {
//         boolean isFile = false; 
//         boolean valid = false; 
       
//         while (!valid) {
//             try {
//                 GraduateStudent student = new GraduateStudent(isFile); 
//                 Search check = new Search (); 
//                 if (check.isInHash(mapStudent, student) == true){
//                    System.out.println("\nWarning: Student already exits!"); 
//                 } else {
//                     studentList.add(student);
//                 }
                   
//                 valid = true; 
//             } catch (Exception e){
//                 System.out.println();
//                 System.out.println(e.getMessage()); 
//                 System.out.println("Try again\n");
//             }
//         }
       
//     }
//     /**
//      * created new Student and add to studentList
//      * @param studentList 
//      */
//     public static void addStudent ( ArrayList <Student> studentList, HashMap <String, Student> mapStudent) { //creates a student and add it to studentList
//         boolean isFile = false; 
//         boolean valid = false; 

//         while (!valid) {
//             try {
//                 Student student  = new Student(isFile); 
//                 Search check = new Search(); 
//                 if (check.isInHash(mapStudent, student) == true){
//                     System.out.println("\nWarning: Student already exits!"); 
//                  } else {
//                     studentList.add(student); 
//                  }
             
//                 valid = true; 
//             } catch (Exception e){
//                 System.out.println();
//                 System.out.println(e); 
//                 System.out.println("Try again\n"); 
//             }
//         }       

//     }
//     /**
//      * print List of GraduateStudents and/or Students
//      */
//     public static void printList ( ArrayList <Student> studentList) { //prints studentList
//         System.out.println(); 
//         for (int i = 0; i < studentList.size(); i++) {
//             System.out.println(studentList.get(i).toString(false)); 
//         }
//         System.out.println("\n"); 
//     }
//     /**
//      * calculates the average and prints it 
//      * @param studentList
//      */
//     public static void classAverage ( ArrayList <Student> studentList) { //calculates the classAverage 
//         double percentage = 0; 
//         double divideBy = 0; 
//         for (int i = 0; i < studentList.size(); i++) {
//             percentage += studentList.get(i).getPercentage(); //adds the percantage of each student when it iterates through the list 
//             divideBy = i; 
//         }
//         Lab4.classAverage = percentage/(divideBy+1); //calculates the class Average
//         System.out.printf("Total Number of Students: %d \nClass Avergae: %.1f \n\n", studentList.size(), getClassAverage()); 
//     }

//     public static double getClassAverage () {
//         return classAverage; 
//     }

// }