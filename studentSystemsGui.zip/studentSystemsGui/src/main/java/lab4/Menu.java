package lab4; 

import java.util.*; 
import javax.swing.JComboBox;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.Border;

import java.awt.BorderLayout;

import java.awt.FlowLayout;
import javax.swing.JButton; 

import java.awt.GridLayout;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JMenuBar;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Menu extends JFrame {
   
    //student textfields
    private JTextField program;  private JTextField year;  private JTextField average; 
    private JTextField lastName;   private JTextField supervisor; //mandatory
    private JTextField isPHD; private JTextField undergraduateSchool; private JComboBox whichStudent; 
    private JPanel s; private JPanel ph; private JPanel  u ; private JPanel readFile; private JPanel writeFile; private JPanel search;
    
    private JTextField fileNameRead;  private JTextField fileNameWrite; private JTextField searchText;

    private ArrayList <Student> studentList = new ArrayList<Student>(); 
    private HashMap <String, Student > mapStudent = new HashMap <String, Student> (); 
  //  private JTextArea = new JTextArea (); 

   private JPanel allTextFields; //private JLabel progrJLabel;  private JLabel year

   private JPanel studentPanel; 
   private JTextArea messageArea; 

    public static void main (String [] args) {
        Menu gui = new Menu (); 
        gui.setVisible(true);
    }

    public class QuitListener implements ActionListener {
        public void actionPerformed (ActionEvent e) {
            System.exit(0);
           
        }
   }



   public class DropDownListener implements ActionListener {
    public void actionPerformed (ActionEvent e) {

        JComboBox typeBox = (JComboBox) e.getSource();
        String student = (String) typeBox.getSelectedItem();

        if( student.equals("Student")) {
            s.setVisible(false);
            ph.setVisible(false);
            u.setVisible(false);
          
        } else {
            s.setVisible(true);
            ph.setVisible(true);
            u.setVisible(true);
        }
    }
}
   
public class Option1Listener implements ActionListener {
  
    public void actionPerformed (ActionEvent e) {
        messageArea.setText(""); 

        readFile.setVisible(false);
        writeFile.setVisible(false);
        search.setVisible(false);
    
        studentPanel.setVisible(true);
        String student = (String) whichStudent.getSelectedItem(); 

        if( student.equals("Student")) {
            s.setVisible(false);
            ph.setVisible(false);
            u.setVisible(false);
          
        } else {
            s.setVisible(true);
            ph.setVisible(true);
            u.setVisible(true);
        }

      
    }
}
public class AddButtonListener implements ActionListener {
    public void actionPerformed (ActionEvent e) {
       
        messageArea.setText("");
        String student = (String) whichStudent.getSelectedItem(); 

        if( student.equals("Student")) {
            createStudent();
        } else {
            createGradStudent();
        }
    
       
    }
}

public class PrintSButtonListener implements ActionListener {
     public void actionPerformed (ActionEvent e) {
        messageArea.setText(""); 
        for (Student student : studentList ) {
            messageArea.append(student.toString(false));
        }
    }
}

public class PrintAButtonListener implements ActionListener {
    public void actionPerformed (ActionEvent e) {
       messageArea.setText(""); 
       classAverage(studentList);
   }
}

public class Option4Listener implements ActionListener {
  
    public void actionPerformed (ActionEvent e) {
        messageArea.setText(""); 
        studentPanel.setVisible(false);      
        writeFile.setVisible(false);
        search.setVisible(false);

        readFile.setVisible(true);  
    }
}

public class Option5Listener implements ActionListener {
  
    public void actionPerformed (ActionEvent e) {
        messageArea.setText(""); 
        studentPanel.setVisible(false);        
        search.setVisible(false);
        readFile.setVisible(false); 
        
        writeFile.setVisible(true);
    
    }
}

public class Option6Listener implements ActionListener {
  
    public void actionPerformed (ActionEvent e) {
        messageArea.setText(""); 
        studentPanel.setVisible(false);        
        readFile.setVisible(false); 
        writeFile.setVisible(false);

        search.setVisible(true);
    
    }
}

public class ReadFileListener implements ActionListener {
  
    public void actionPerformed (ActionEvent e) {
         messageArea.setText(""); 
        FileIO fileIO = new FileIO(); 
         try {
             fileIO.loadFile(studentList, mapStudent, fileNameRead.getText());
             messageArea.setText("File succesfully loaded");
         } catch (Exception e1) {
             messageArea.setText(e1.getMessage());
         }
       fileNameRead.setText("");
    }
}
public class WriteFileListener implements ActionListener {
  
    public void actionPerformed (ActionEvent e) {
        messageArea.setText(""); 
       
         try {
            FileIO file = new FileIO(); 
             file.saveFile(studentList, fileNameWrite.getText());
             messageArea.setText("File successfully written");
         } catch (Exception e1) {
             messageArea.setText(e1.getMessage());
         }
         fileNameWrite.setText("");
       // allTextFields.setVisible(true);
    }
}

public class SearchListener implements ActionListener {
  
    public void actionPerformed (ActionEvent e) {
         messageArea.setText("");
        Search search = new Search(); 

        messageArea.setText(search.searchByHashMaps(mapStudent, searchText.getText()));
        
        searchText.setText("");
    }
}

  //constructor 
   public Menu () {

    setLayout(new BorderLayout());
    setSize(1100, 600);
    setBackground(Color.BLUE);

    createButtons();

    addTextFields();

    JPanel messPanel = new JPanel (); 
    BoxLayout layout = new BoxLayout(messPanel,BoxLayout.Y_AXIS); 
    messPanel.setLayout(layout); 
  

    JPanel messJPanel = new JPanel (new FlowLayout(FlowLayout.LEFT)); 
    JLabel message = new JLabel ("Messages");
    messJPanel.add(message); 

    messageArea = new JTextArea(10,15);
    messageArea.setLineWrap(true);
    messageArea.setEditable(false);


    messPanel.add(messJPanel); 

   JScrollPane messagesScroll = new JScrollPane(messageArea);
    messJPanel.add(messagesScroll); 

   //messPanel.add(messJPanel); 
   messPanel.add(messagesScroll);
   
   add(messPanel, BorderLayout.PAGE_END);
   
    


   }

   public void createButtons () {

    //JPanel gridPanel = new GridLayout (5, 0); 

    JPanel innerbuttoJPanel =  new JPanel (new FlowLayout (FlowLayout.LEFT));
    innerbuttoJPanel.setBackground(Color.CYAN);

    JPanel addPanel =  new JPanel (new FlowLayout (FlowLayout.LEFT));
    addPanel.setBackground(Color.CYAN); 

    JLabel typeLabel = new JLabel("type: ");
    String [] studentStrings = {"Student", "Graduate Student"};
    whichStudent = new JComboBox (studentStrings);
   
    whichStudent.setSelectedIndex(0); //book
    whichStudent.addActionListener( new DropDownListener() );

    addPanel.add(typeLabel); 
    addPanel.add(whichStudent);
    
    innerbuttoJPanel.add(addPanel);


    JButton option1 = new JButton ("Enter a Student"); 
    option1. addActionListener(new Option1Listener());
    innerbuttoJPanel.add(option1); 
    
    JButton option2 = new JButton ("Print Student"); 
    option2. addActionListener(new PrintSButtonListener());
    innerbuttoJPanel.add(option2); 

    JButton option3 = new JButton ("Print Average"); 
    option3. addActionListener(new PrintAButtonListener());
    innerbuttoJPanel.add(option3); 

    JButton option4 = new JButton ("Read File"); 
    option4. addActionListener(new Option4Listener());
    innerbuttoJPanel.add(option4); 

    JButton option5 = new JButton ("Write File"); 
    option5. addActionListener(new Option5Listener());
    innerbuttoJPanel.add(option5); 

    JButton option6 = new JButton ("Search"); 
    option6. addActionListener(new Option6Listener());
    innerbuttoJPanel.add(option6); 

    JButton option7  = new JButton ("Quit"); 
    option7. addActionListener(new QuitListener());
    innerbuttoJPanel.add(option7); 

    add(innerbuttoJPanel, BorderLayout.PAGE_START);

   }

   public void createStudent () {
     

        try {
            String pString =  program.getText(); 
            String [] program  =  pString.split("[ ]+"); 
            Student student  = new Student (program, year.getText(), average.getText(), lastName.getText()); 
            Search check = new Search(); 
            if (check.isInHash(mapStudent, student) == true){
                messageArea.setText("Warning: Student already exits!");  
            } else {
                studentList.add(student); 
            }
            check.addToHashMap(mapStudent, studentList);  //add key and value to HashMap
    
        } catch (Exception e) {
            messageArea.setText(e.getMessage());
        }

        program.setText("");
        year.setText("");
        average.setText("");
        lastName.setText("");
        supervisor.setText("");
        isPHD.setText("");
        undergraduateSchool.setText("");
           
   }

   public void createGradStudent () {
   
        try {
            String pString =  program.getText(); 
            String [] program  =  pString.split("[ ]+");  
            GraduateStudent student  = new GraduateStudent(program, year.getText(), average.getText(), lastName.getText(), supervisor.
            getText(), isPHD.getText(), undergraduateSchool.getText());
            Search check = new Search(); 
            if (check.isInHash(mapStudent, student) == true){
                messageArea.setText("Warning: Student already exits!"); 
            } else {
                studentList.add(student); 
            }
            System.out.println(student.toString(false));
            check.addToHashMap(mapStudent, studentList);  //add key and value to HashMap
        } catch (Exception e){
            messageArea.setText(e.getMessage());
        }
    
        program.setText("");
        year.setText("");
        average.setText("");
        lastName.setText("");
        supervisor.setText("");
        isPHD.setText("");
        undergraduateSchool.setText("");

    }

     /**
     * calculates the average and prints it 
     * @param studentList
     */
    public void classAverage ( ArrayList <Student> studentList) { //calculates the classAverage 
        double percentage = 0; 
        double divideBy = 0; 
        for (int i = 0; i < studentList.size(); i++) {
            percentage += studentList.get(i).getPercentage(); //adds the percantage of each student when it iterates through the list 
            divideBy = i; 
        }
        double average = (percentage/(divideBy+1)); 

        messageArea.setText("Total Number of Students: " +  studentList.size() + "\nClass Avergae: " + average);
    }

   public void addTextFields () {
       JPanel allTextFields = new JPanel (); 
       studentPanel = new JPanel (); 
       BoxLayout layout = new BoxLayout(studentPanel, BoxLayout.Y_AXIS); 
       studentPanel.setLayout(layout);
       //gradStudPanel = new JPanel (new FlowLayout(FlowLayout.LEFT) ); 

       JPanel p = new JPanel (new FlowLayout(FlowLayout.LEFT)); 
       JLabel A= new JLabel( "    "); 
       JLabel programLabel = new JLabel ("Program:  "); 
       program = new JTextField (15); 
       p.add(programLabel); 
       p.add(A); 
       p.add(program); 
       studentPanel.add(p); 

       JPanel y = new JPanel (new FlowLayout(FlowLayout.LEFT)); 
       JLabel yearLabel = new JLabel ("Year:  "); 
       JLabel B = new JLabel( "         "); 
       year = new JTextField (15); 
       y.add(yearLabel); 
       y.add(B); 
       y.add(year); 
       studentPanel.add(y); 
       

       JPanel a = new JPanel (new FlowLayout(FlowLayout.LEFT)); 
       JLabel averageLabel = new JLabel ("Average:  "); 
       JLabel C = new JLabel( "    "); 
       average = new JTextField (15); 
       a.add(averageLabel); 
       a.add(C); 
       a.add(average);
       studentPanel.add(a); 

       JPanel l = new JPanel (new FlowLayout(FlowLayout.LEFT)); 
       JLabel lastNameLabel = new JLabel ("Last Name:  "); 
       //JLabel D = new JLabel( "  "); 
       lastName = new JTextField (15); 
       l.add(lastNameLabel); 
       //l.add(D); 
       l.add(lastName); 
       studentPanel.add(l); 
       
        s = new JPanel (new FlowLayout(FlowLayout.LEFT)); 
       JLabel superVLabel = new JLabel ("Supervisor:  "); 
       //JLabel E = new JLabel( " "); 
       supervisor = new JTextField (15); 
       s.add(superVLabel); 
       //s.add(E); 
       s.add(supervisor);
       studentPanel.add(s); 

       ph = new JPanel (new FlowLayout(FlowLayout.LEFT)); 
       JLabel isPhdLabel = new JLabel ("Ph? :  "); 
       JLabel F = new JLabel( "        "); 
       isPHD = new JTextField (15); 
       ph.add(isPhdLabel); 
       ph.add(F); 
       ph.add(isPHD);
       studentPanel.add(ph); 
       
        u = new JPanel (new FlowLayout(FlowLayout.LEFT)); 
       JLabel undergradLabel = new JLabel ("School:  "); 
       JLabel G = new JLabel( "    "); 
       undergraduateSchool = new JTextField (15); 
       u.add(undergradLabel); 
       u.add(G); 
       u.add(undergraduateSchool); 
       studentPanel.add(u); 

    

       JPanel butJPanel = new JPanel ( new FlowLayout(FlowLayout.CENTER)); 
       JButton addButton = new JButton ("Add");
       addButton.addActionListener(new AddButtonListener()); 
       butJPanel.add(addButton);

       studentPanel.add(butJPanel); 

       allTextFields.add(studentPanel);   //add Student Fields
     
       readFile = new JPanel (new FlowLayout(FlowLayout.LEFT)); 
       JLabel readLabel = new JLabel ("Enter a file: ");
       fileNameRead = new JTextField (15); 

        JButton readButton = new JButton ("Read");
        readButton.addActionListener(new ReadFileListener()); 

        readFile.add(readLabel); 
        readFile.add(fileNameRead);
        readFile.add(readButton); 

        allTextFields.add(readFile);  //add readFile 
    //    JPanel readJPanel = new JPanel ( new FlowLayout(FlowLayout.LEFT)); 
    //    JButton readButton = new JButton ("Enter");
    //    readButton.addActionListener(new AddButtonListener()); 


       writeFile = new JPanel (new FlowLayout(FlowLayout.LEFT)); 
       JLabel writeLabel = new JLabel ("Enter a file: "); //add writeFile
       fileNameWrite = new JTextField (15); 

       JButton writeButton = new JButton ("Write");
       writeButton.addActionListener(new WriteFileListener());
       
       writeFile.add(writeLabel); 
       writeFile.add(fileNameWrite);
       writeFile.add(writeButton); 


       allTextFields.add(writeFile); 

       search = new JPanel (new FlowLayout(FlowLayout.LEFT)); 
       JLabel searchLabel = new JLabel ("Enter Search (HashMap): ");
       searchText = new JTextField (15); 
       
       //search.add(search); 
       //search.add(searchLabel); 
       //search.add(searchText);

       JButton searchButton = new JButton ("Search");
       searchButton.addActionListener(new SearchListener());

        
        search.add(searchLabel); 
        search.add(searchText);
        search.add(searchButton); 

        allTextFields.add(search); 
       
       allTextFields.add(search); 


       add(allTextFields, BorderLayout.LINE_START); 

       readFile.setVisible(false);
       writeFile.setVisible(false);
       search.setVisible(false);
   
       studentPanel.setVisible(true);
       s.setVisible(false);
       ph.setVisible(false);
       u.setVisible(false);

   }


}