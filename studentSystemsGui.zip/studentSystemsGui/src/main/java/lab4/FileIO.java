package lab4; 
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import java.io.File; 
import java.util.HashMap;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter; 

public class FileIO {

    /**
     * this function is to read from a file and store in list (each line)
     * @param studentList is used store info from file.txt
     */
    public void loadFile (ArrayList <Student> studentList, HashMap <String, Student> mapStudent, String fileName) throws RequiredInputException {
        try {
            // Scanner filename = new Scanner (System.in); 
            // System.out.print("Enter filename: "); 
            // String fileName = filename.nextLine(); 
            File tempFile = new File (fileName); 
            if (tempFile.length() == 0) { //check if the file is isEmpty
                System.out.println ("Error: File is empty\n"); 
                System.exit(0); 
            }
            Scanner input = new Scanner (new FileInputStream(fileName)); // read in file
            try { 
                readFile (input, studentList, mapStudent); //read the file in line by line and set the attribute 
            } catch (Exception e) {
                throw new RequiredInputException(e.getMessage()); 
            }
            //System.out.println ("Students successfully loaded from " + fileName); 
            System.out.println(); 
        } catch (Exception e) {
           // System.out.println ("Error: Could not open file\n"); 
           throw new RequiredInputException(e.getMessage()); 

        }
    }
    /**
     * this function reads to files
     * @param studentList is the info that is used to write to file.txt
     */
    public void saveFile (ArrayList <Student> studentList, String file)  throws RequiredInputException {
        try {
            // Scanner filename = new Scanner (System.in); 
            // System.out.print("Enter filename: "); 
            // String file = filename.nextLine(); 
            File tempFile = new File (file); //if this file already exists
            tempFile.delete();                      //then delete it cause we want to "rewrite file"

            for (int i = 0; i < studentList.size(); i++) { // iterate through student List
                PrintWriter fileWriter = new PrintWriter (new FileOutputStream(file, true)); //open files to write. true b/c appending to list
                fileWriter.println(studentList.get(i).toString()); //write to list on each list
                fileWriter.close();       //dont't need to close -> java automatically closes list       
            }

            studentList.removeAll(studentList); //remove all elements in List
            System.out.println(); 
        } catch (Exception e) {
          //  System.out.println ("Error: Could not write to file\n");
            throw new RequiredInputException("Error: Could not write to file"); 
        }
    }
    /**
     * 
     * @param input is the line for the file   
     * @param studentList is the list that stores object after reading and setting. 
     */
    public void readFile (Scanner input, ArrayList <Student> studentList, HashMap <String, Student> mapStudent) throws RequiredInputException { 
        while (input.hasNextLine()) {
            String [] inputStrings = input.nextLine().split(" "); 
            if (inputStrings.length == 4) {
                boolean isFile = true;  
                 try {
                     Student student = new Student (isFile);
                     Search check = new Search (); 
                     setAttributesStudent(student, inputStrings);
                    //studentList.add(student); 
                    if (check.isInHash(mapStudent, student) == true){
                       // System.out.println("\nWarning: Student already exits!");
                        throw new RequiredInputException("Warning: Student already exits!"); 
                     } else {
                         studentList.add(student);
                         check.addToHashMap(mapStudent, studentList);  //add key and value to HashMap
                    }
                     
                 } catch (Exception e) {
                    throw new RequiredInputException(e.getMessage()); 
                     //System.out.println(e.getMessage()); 
                 }
               
            }
            if (inputStrings.length > 4) {
                 boolean isFile = true;                 
                 try {
                    Search check = new Search (); 
                    GraduateStudent student = new GraduateStudent (isFile);
                    setAttributesGradS(student, inputStrings);
                    // studentList.add(student); 
                    if (check.isInHash(mapStudent, student) == true){
                      //  System.out.println("\nWarning: Student already exits!"); 
                       throw new RequiredInputException("Warning: Student already exits!"); 
                     } else {
                         studentList.add(student);
                         check.addToHashMap(mapStudent, studentList);  //add key and value to HashMap
                     }  
                } catch (Exception e) {
                  //  System.out.println(e.getMessage()); 
                   throw new RequiredInputException(e.getMessage()); 
                }
            }
        }
    }
    /**
     * sets instance variables for Student 
     * @param student is Student object
     * @param inputStrings is an array of strings from the line in a file
     */
    private void setAttributesStudent (Student student, String [] inputStrings) {
        student.setProgram(inputStrings[0]); 
        student.setYear(inputStrings[1]); 
        student.setPercentage(inputStrings[2]);
        student.setLastName(inputStrings[3]); 

    }
    /**
     * sets instance variables for GraduateStudent
     * @param student is GraduateStudent object 
     * @param inputStrings is an array of string from the line in a file
     */
    private void setAttributesGradS (GraduateStudent student, String [] inputStrings) {
        student.setProgram(inputStrings[0]); 
        student.setYear(inputStrings[1]); 
        student.setPercentage(inputStrings[2]); 
        student.setSupervisor(inputStrings[3]);
        student.setPHD(inputStrings[4]); 
        student.setUndergraduateSchoo(inputStrings[5]);
        student.setLastName(inputStrings[6]); 
    }


}