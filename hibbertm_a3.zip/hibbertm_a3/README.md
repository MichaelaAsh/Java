This program builds by using gradle build or ./gradlew build on terminal in this folder 
It runs by using going to build/classes/java/main and typing java eStoreSearch.eStore <filename>
To test JUnit tests, use gradle test or ./graldew test on terminal in this folder

## PROGRAM PURPOSE:
This program is main is in eStore.java. 
This programs loads products from a file (it can also be an empty), into an ArrayList of Products
The program ask user for three Menu options. Search, Add and Quit. 
When user quits the program, the program will write the products to the file the user specified on the command line -> eStoreSearch.eStore <filename>

## ADD: 
If the users wants to add, it will display a panel for attributes they can add. By default, the Drop down Box is set to book, but the user can change it to Electronics to add an electronic. Once the user done, press add. Press reset to clear the fields.
ProductId, Description, and Year is required.

## SEARCH: 
If the user wants to search, it will display a panel for productID, keywords, Start Years and End Year. Any or all can be empty. Press search to perform
a search. Press reset to reset textFields
If search prompts are all empty, then everything will be printed. 

## Quit 
When user quits the program, the program will write the products to the file the user specified on the command line -> eStoreSearch.eStore <filename>
There are two ways to quit -> by pressing X or pressing the menu option "Quit"

## ERROR CHECK: 
The program will output error in message Panel if format is wrong or if an input is required and user didn't input
The program will not take in wrong input. 

For add: productID must be 6 digits and is required, description is required and year must be 4 digits betweeen 1000-9999
and is also required

For search: productID must be 6 digits and is not required, description is not required and year must be 4 digits between 1000-9999
and can be if the formart year, -year, year- or year-year

This program will not run without <filename> given on command line

## IMPROVEMENTS 
The search uses HashMaps to make a more effecient search. -> HashMap <String, ArrayList <Integer>>
If the user inputs a keyword the HashMaps is created with the keyword as the key and value is the index of a product in a productList that has that keyword in its description
Implimented a GUI

## LIMITATIONS:
If the user puts in a leading space before any commands or Type it will ask again. 
If the user puts in a leading space before any input in search it will not find it. 
if the user puts in a leading spaces when adding an item attribute that is required, it will ask user again
If the user must not have space between the time period format for seach

## POSSIBLE IMPROVEMENT: 
Find a way to fix the limitations





