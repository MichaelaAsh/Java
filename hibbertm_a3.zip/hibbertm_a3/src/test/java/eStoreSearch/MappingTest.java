package eStoreSearch; 

import org.junit.Test;  
import java.util.ArrayList;
import static org.junit.Assert.*;

public class MappingTest {

    private ArrayList <Product> fromFileProductList = new ArrayList <Product> (); 
    
    @Test
    public void readTest () {
        FileIO readFile = new FileIO(fromFileProductList);        

        readFile.loadFile("file.txt"); //load file into arrayList of products 

        assertTrue(fromFileProductList.get(0).getProductID().equals("000025")); 
        assertTrue(fromFileProductList.get(1).getProductID().equals("000107")); 
        
        assertTrue(fromFileProductList.get(0).getDescription().equals("Absolute Java")); 
        assertTrue(fromFileProductList.get(1).getDescription().equals("MacBook Air 11\" Intel Dual-Core i5 1.6GHz")); 
        
        assertTrue(fromFileProductList.get(0).getYear().equals("2015"));
        assertTrue(fromFileProductList.get(1).getYear().equals("2013"));

        assertTrue(fromFileProductList.get(0).getPrice() == 199.95);

        Book book = new Book (); 
        book.setProductID("000123"); 
        book.setDescription("Nancy Drew Hidden StairCase"); 
        book.setYear("1930"); 
        book.setPrice("21.99"); 
        fromFileProductList.add(book);  //add to list

        
        Book book1 = new Book (); 
        book1.setProductID("000124"); 
        book1.setDescription("Nancy Drew  Secret of the Old Clock"); 
        book1.setYear("1930"); 
        book1.setPrice("21.99"); 
        fromFileProductList.add(book); //add to list

        assertTrue(fromFileProductList.get(2).getProductID().equals("000123")); 
        assertTrue(fromFileProductList.get(2).getDescription().equals("Nancy Drew Hidden StairCase"));
        assertTrue(fromFileProductList.get(2).getYear().equals("1930")); 
        assertTrue(fromFileProductList.get(2).getPrice() == 21.99);

        EStoreSearch search  = new EStoreSearch ( new ArrayList <Product> (fromFileProductList)); 

        search.setKeyword("Nancy Drew");  
        ArrayList <Integer> numArray = new ArrayList <Integer> ();
        numArray.add(2); 
        numArray.add(3); 
        search.mappingKeywords(); //create HashMaps of keywords
        assertEquals(search.getIntersectionList(), numArray);  

        numArray.remove( new Integer(2)); //remove 2 from list 
        numArray.remove(new Integer(3));  // remove 3 from list

        numArray.add(1);  //add 1 to list
        search.setKeyword("MacBook Air 11\"");  
        search.mappingKeywords(); //create hashMaps of keywords 
        assertEquals(search.getIntersectionList(), numArray); 
          
        search.setProductID(""); 
        search.setKeyword(""); 
        search.setYear("1930");
        assertEquals(2, search.search());
       
        search.setProductID("");
        search.setKeyword("Nancy");  
        search.setYear("1930");
        assertEquals(2, search.search());
    

    }


}