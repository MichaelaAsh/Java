package eStoreSearch; 

import org.junit.Test; 
import static org.junit.Assert.*;
import java.util.*; 

    public class eStoreAddTest {
        @Test public void errorCheck3() { 

            ArrayList<Product>productList = new ArrayList<Product>(); // create array list of the object Product

            Book [] book  = new Book [2]; 
            for (int i = 0; i < 2; i++) {
                book[i] = new Book (); //allocate memory for each book
            }
        
            book[0].setProductID("000123");
            book[1].setProductID("123456"); 
            
            productList.add(book[0]); 
            productList.add(book[1]); 

            Electronics electronic = new Electronics(); 
            electronic.setProductID("000123"); 


            assertTrue(electronic.checkProductId(productList));
            assertEquals(2,productList.size()); 
        
        
    }
//////////////////////////////////////////////////////////////////////////////////////
   // public static void returnProductArray(ArrayList <Product> productList) {
       

}    