package eStoreSearch; 

import org.junit.Test; 
import java.util.*; 
import static org.junit.Assert.*;

public class eStoreInputTest {
      @Test public void errorCheck1() {  // Testing for user input for book, electronics, and eStoreSearch 

         Book book = new Book();  
         //productId must be 6 digits long/ not empty
         assertFalse(book.setProductID("1234567")); 
         assertFalse(book.setProductID(""));   
         assertFalse(book.setProductID("abcdef"));  
        
         assertTrue(book.setProductID("123456")); 

        //descrtiption must not be empty
         assertFalse(book.setDescription("")); 

         assertTrue(book.setDescription("A dystopia book")); 
         
         //year must 4 long, be between 1000 and 9999 inclusive and not be empty
         assertFalse(book.setYear("12345")); 
         assertFalse(book.setYear("999"));
         assertFalse(book.setYear("0023"));
         assertFalse(book.setYear(""));  

         assertTrue(book.setYear("1234"));  

        //price be an integer or integer
         assertFalse(book.setPrice("abcd")); 
         assertFalse(book.setPrice("12.abcd")); 
         assertFalse(book.setPrice("abcd.12"));

         assertTrue(book.setPrice("1234")); 
         assertTrue(book.setPrice("123.34"));
         
        ///////////////////////////////////////
        //error check for search input
         ArrayList <Product> productList = new ArrayList <Product> (); 
         EStoreSearch search = new EStoreSearch (new ArrayList <Product> (productList)); //contructor for testing (no user input)

         //year must 4 long, be between 1000 and 9999 inclusive and can be in format year only, - year, year- or year - year
         assertFalse(search.setYear("3000-2000")); 
         assertFalse(search.setYear("300-")); 
         assertFalse(search.setYear("-20")); 
         assertFalse(search.setYear("20")); 

         assertTrue(search.setYear("-2000")); 
         assertTrue(search.setYear("3000-")); 
         assertTrue(search.setYear("2000")); 
         assertTrue(search.setYear("2000-3000")); 
         assertTrue(search.setYear("")); 
         assertTrue(search.setYear("1234")); 

         assertFalse(search.setYear("12345")); 
         assertFalse(search.setYear("999"));
         assertFalse(search.setYear("0023"));

        //productId must be 6 digits long/ not empty
        assertFalse(search.setProductID("1234567"));    
        assertFalse(search.setProductID("abcdef"));  
        
        assertTrue(search.setProductID(""));
        assertTrue(search.setProductID("123456")); 

        //descrtiption must not be empty
        assertTrue(search.setKeyword("")); 
        assertTrue(search.setKeyword("A dystopia book"));
 

     }
}