// package eStoreSearch; 

// import org.junit.Test; 
// import static org.junit.Assert.*;
// import java.util.*; 

//     public class eStoreSearchTest {
//         @Test public void errorCheck2() { //Testing if eStoreSearch search method, which return number of matches


//             ArrayList<Product>productList = new ArrayList<Product>(); // create array list of the object Book

//             EStoreSearch search1= new EStoreSearch("Test",productList );        
//             search1.setProductID(" "); 
//             search1.setKeyword(" "); 
//             search1.setYear("1955-2020");

//             productList = returnArrayList(productList); //creates an arrays of books 

             
//             EStoreSearch search2 = new EStoreSearch("Test", productList);        
//             search2.setProductID(""); 
//             search2.setKeyword(""); 
//             search2.setYear("1954-");
//             assertEquals(2, search2.search());   

//             EStoreSearch search5 = new EStoreSearch("Test", productList);        
//             search5.setProductID("000123 "); 
//             search5.setKeyword("IPHONE"); 
//             search5.setYear("2017");
//             assertEquals(1, search5.search());  

//             EStoreSearch search13 = new EStoreSearch("Test", productList);  
//             search13.setProductID(""); 
//             search13.setKeyword(""); 
//             search13.setYear("");
//             assertEquals(-1, search13.search()); //if input are empty for search it should return -1
            
//         }
// //////////////////////////////////////////////////////////////////////////////////
//         public static ArrayList returnArrayList (ArrayList <Product> productList) {
//             Book book1 = new Book(); 
//             book1.setProductID("000123");
//             book1.setDescription("To Kill a MockingBird");
//             book1.setYear("1960"); 
//             book1.setPrice("25.99"); 
//             book1.setAuthor("Harper Lee");
//             productList.add(book1); 

//             Electronics electronic1 = new Electronics(); 
//             electronic1.setProductID("000123"); 
//             electronic1.setDescription("IPhone 8");
//             electronic1.setYear("2017"); 
//             electronic1.setPrice("600.99"); 
//             electronic1.setMaker("Apple Inc.");
//             productList.add(electronic1); 

//             return productList;
//         }
    
// }