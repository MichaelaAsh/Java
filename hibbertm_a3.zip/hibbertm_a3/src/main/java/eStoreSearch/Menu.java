package eStoreSearch;

import java.util.*; 
import javax.swing.JComboBox;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import java.awt.BorderLayout;

import java.awt.FlowLayout;
import javax.swing.JButton; 

import java.awt.GridLayout;
import java.awt.Component;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JMenuBar;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Menu extends JFrame {

    public static final int WIDTH = 750; 
    public static final int HEIGHT = 700; 
  
    //Panel for menu options + initial Panel (Welcome)
    private JPanel addPanel; 
    private JPanel searchPanel;
    private JPanel initialPanel;


    //TextFields will jold instance variables for EStoreSearch, Product, Electronics and/or Book
    private JTextField productId;  private JTextField productId2; private JTextField description; private JTextField description2; private  JTextField price;
    private JTextField year; private JTextField maker; private JTextField authors; private  JTextField publisher; private JTextField eYear; private JTextField sYear;
    private JTextArea messageArea; private JTextArea searchResults; 
    private JComboBox productOptions; private String file; 

   private  ArrayList <Product> productList = new ArrayList <Product> (); //used to store the products
     /**
     * main method
     * @param args
     */
    public static void main (String [] args) {
        Menu gui = new Menu (); 
        gui.setVisible(true);

        if (args.length < 1) { //no argument/file has been put on command line
             System.exit(0);
        } else {
            
            FileIO fileInput = new FileIO (gui.getProductList()); 
            gui.file = args[0]; 
            fileInput.loadFile(gui.file);
            gui.productList = fileInput.getProductList();     

        }
    
       
    }
    /**
     * Sets Add Panel when search menu item is called
     */
    public class AddListener implements ActionListener {
         public void actionPerformed (ActionEvent e) {
             initialPanel.setVisible(false);
             
             addPanel.setVisible(true);
             bookAttributes();
             searchPanel.setVisible(false);
            
         }
    }
  /**
   * Set Search Panel when search Menu Item is called
   */
    public class SearchListener implements ActionListener {
        public void actionPerformed (ActionEvent e) {
            initialPanel.setVisible(false);
            addPanel.setVisible(false);
            searchPanel.setVisible(true);
        }
    }

   /**
    * Exit Program when quit menu option is called
    */
    public class QuitListener implements ActionListener {
        public void actionPerformed (ActionEvent e) {
                 
            FileIO fileInput = new FileIO (getProductList()); 
            try {
                fileInput.saveFile(file);
            } catch (Exception e1) {
                System.exit(0);
            }

            System.exit(0);
           
        }
   }
    /**
     * 
     * @return a copy of the ArrayList
     */
    public ArrayList<Product> getProductList() {
        return new ArrayList  <Product> (productList);
    }


    /**
     * Reset Add Panel
     */
    public class ResetListener implements ActionListener {
        public void actionPerformed (ActionEvent e) {
            productId.setText("");
            description.setText("");
            price.setText("");
            year.setText("");
            maker.setText("");
            authors.setText("");
            publisher.setText("");
            messageArea.setText("");
        }
    }
   /**
    * Reset Search Panel
    */
    public class ResetSearchListener implements ActionListener {
        public void actionPerformed (ActionEvent e) {
            productId2.setText("");
            description2.setText("");
            sYear.setText("");
            eYear.setText("");
            searchResults.setText("");
        }
    }
   /**
    * For product options 
    */
    public class DropDownListener implements ActionListener {
        public void actionPerformed (ActionEvent e) {

            JComboBox typeBox = (JComboBox) e.getSource();   //get selectd String from JComboBox
            String product = (String) typeBox.getSelectedItem();

            if( product.equals("book")) {
                bookAttributes();  //set panel for book
            } else {
                elecAttributes();  //set panel for electronics 
            }
        }
    }
   /**
    * Add Button Listen to class
    */
    public class AddButtonListener implements ActionListener {
        public void actionPerformed (ActionEvent e) { 
    
            String product = (String) productOptions.getSelectedItem();  //get selectd String from JComboBox

            if( product.equals("book")) { //if it's a book call addBook which create a new book and adds to productList
                
                addBook(productId.getText(),description.getText(),  price.getText(), year.getText(), authors.getText(), publisher.getText());
            } else {  //if it's a electronicss call elecBook which create a new book and adds to productList
                addElec(productId.getText(),description.getText(),  price.getText(), year.getText(), maker.getText());
            }
            
        }
    }
    /**
     * search button listener class
     */
    public class SearchButtonListener implements ActionListener {
        public void actionPerformed (ActionEvent e) {
            searchResults.setText("");  //clear previous search results
            try {
                String Year; 
                if (sYear.getText().isEmpty() && eYear.getText().isEmpty() ) {
                    Year = " "; //if it's empty then send an empty string
                } else {
                    Year = sYear.getText() + "-" + eYear.getText(); //create year-year
                }
        
                EStoreSearch search = new EStoreSearch(productId2.getText(),description2.getText(),Year, getProductList());   
  
                search.search();  //search for input
                for (Product product:search.getProductList()) {
                    searchResults.append(product.toString()); //print to searchResults JTextArea
                    searchResults.append("\n");
                }
              
            } catch (Exception exception) {
                searchResults.setText(exception.getMessage());
            }

        }
    }

    /**
     * set Panel to show panels for Electronics 
     */
    private void elecAttributes () {
        Component myPanel[] = addPanel.getComponents();

        JPanel panel = (JPanel) myPanel[0]; 
        Component myComp[] = panel.getComponents(); 

        JPanel author = (JPanel)myComp[6]; 
        author.setVisible(false);

        JPanel publisher = (JPanel)myComp[7];
        publisher.setVisible(false); 

        JPanel maker = (JPanel)myComp[8]; 
        maker.setVisible(true);
       
    }
     /**
      * set Panel to book Attributes 
      */
    private void bookAttributes () {
        Component myPanel[] = addPanel.getComponents();

        JPanel panel = (JPanel) myPanel[0]; 
        Component myComp[] = panel.getComponents(); 

        JPanel author = (JPanel)myComp[6];
        author.setVisible(true);

        JPanel publisher = (JPanel)myComp[7]; 
        publisher.setVisible(true);

        JPanel maker = (JPanel)myComp[8]; 
        maker.setVisible(false);
       
    }

   /**
    * create book object and stores to list if valid
    * @param productID
    * @param descrip
    * @param price
    * @param year
    * @param authors
    * @param publisher
    */
    private void addBook (String productID, String descrip, String price, String year, String authors, String publisher ) {
        try {
            Book book = new Book(productID, descrip,price,year,authors, publisher, getProductList());
            messageArea.setText("");
            productList.add(book); 
        } catch (Exception e) {     
            messageArea.setText(e.getMessage()); 
        }
    }
    /**
     * create Elec object and store to list 
     * @param productID
     * @param descrip
     * @param price
     * @param year
     * @param maker
     */
    private void addElec(String productID, String descrip, String price, String year, String maker) {
      try {
        Electronics elec = new Electronics(productID, descrip,price,year,maker, getProductList());
        productList.add(elec);
       } catch (Exception e) {
          messageArea.setText(e.getMessage());
       }
    }
   
   
    /**
     * Menu constructor
     */
    public Menu () {
        super("eStoreSearch"); //title 
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
        
        JPanel area = new JPanel (new FlowLayout(FlowLayout.LEFT)); 
        JTextArea textArea = new JTextArea(55, 55); 
        textArea.append("Welcome to to EStoreSearch");
        textArea.append("\n");
        textArea.append("\n");
        textArea.append("\n");
        textArea.append("Choose a command from the Commands menu for above for adding, searching products or quitting the program.");
        textArea.setLineWrap(true);
        textArea.setEditable(false); //can't edit

        textArea.setOpaque(false);
        area.add(textArea); 

        //welcome panel
        initialPanel = new JPanel(); 
        initialPanel.add(area);
        
        mainPanels(); //creates main panels (Welcome window, add, search)
        menuItems(); //create menu items (add, search, quit)
    
    }
    /**
     * create menu items (add, search, quitß)
     */
    public void menuItems () {
        JMenu eStoreMenu = new JMenu ("Commands");   // Command Menu
        
       //add option for command menu
        JMenuItem addChoice = new JMenuItem("Add"); 
        addChoice.addActionListener(new AddListener() );
        eStoreMenu.add(addChoice);
         
       //search option for command menu
       JMenuItem searchChoice = new JMenuItem("Search"); 
       searchChoice.addActionListener(new SearchListener() );
       eStoreMenu.add(searchChoice);

        //quit option for command menu
        JMenuItem quitChoice = new JMenuItem("Quit"); 
        quitChoice.addActionListener(new QuitListener() );
        eStoreMenu.add(quitChoice); 

        JMenuBar bar = new JMenuBar(); //creates new Menu bar
        bar.add(eStoreMenu);
        setJMenuBar(bar);
        
    }
    /**
     * create mainPanels
     */
    public void mainPanels ()  {     
        //first Panel to been shown (Welcome Panel)
        initialPanel.setVisible(true);
        add(initialPanel, BorderLayout.PAGE_START);

        //Panel to add products
        addPanel = new JPanel (new BorderLayout());
        add();
        addPanel.setVisible(false); 
        add(addPanel,  BorderLayout.LINE_START);

        //Panel to search products
        searchPanel = new JPanel(new BorderLayout()); 
        //search
        search();
        searchPanel.setVisible(false);
        add(searchPanel);
    }
    public void add () {
 
        JPanel firstHalf = new JPanel ();  //Panel to hold panel of labels and JTextFields
        JPanel secondHalf = new JPanel (new GridLayout(3, 0));  //Panel to hold Box Layout  Panel of rest and add button
        BoxLayout firsLayout = new BoxLayout(firstHalf,BoxLayout.Y_AXIS);  
        firstHalf.setLayout(firsLayout);
      
        //Adding to product
        JPanel add = new JPanel( new FlowLayout(FlowLayout.LEFT)); 
        JLabel addMessageText = new JLabel ("Adding a product"); 
        add.add(addMessageText);

        
        //Combo Box for product options 
        JLabel label = new JLabel("          "); 
        JLabel typeLabel = new JLabel("type: ");
        String [] productStrings = {"book", "electronics"};
        productOptions = new JComboBox (productStrings);
     
        productOptions.setSelectedIndex(0); //book
        productOptions.addActionListener( new DropDownListener() );
        JPanel productStriPanel = new JPanel ( new FlowLayout(FlowLayout.LEFT)); //create panel to hold the label and JComboBox
    
        //store in panel for type
         productStriPanel.add(typeLabel);
         productStriPanel.add(label); 
         productStriPanel.add(productOptions);
         
         
         //ProductId
        JLabel label4  = new JLabel("  ");
        JLabel productMessage = new JLabel ("ProductID: ");
        productId = new JTextField(30);
        JPanel product = new JPanel(); //create panel to hold the label and JTextFields
     
        //store in panel for productId
        product.add(productMessage);
        product.add(label4); 
        product.add(productId); 

        //Description
        JLabel descriptionMessage = new JLabel ("Description: ");
        description = new JTextField(30);
        JPanel descriptionPanel = new JPanel(); //create panel to hold the label and JTextFields

        //store in panel for description
        descriptionPanel.add(descriptionMessage); 
        descriptionPanel.add(description); 
   
        //Price
        JLabel label1 = new JLabel("      "); 
        JLabel priceMessage = new JLabel ("Price:    ");
        price = new JTextField(10);
        JPanel pricePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));  //create panel to hold the label and JTextFields
        
        //store in panel for price
        pricePanel.add(priceMessage); 
        pricePanel.add(label1); 
        pricePanel.add(price);
       
        //Year 
        JLabel label2 = new JLabel("     "); 
        JLabel yearMessage = new JLabel ("Year:      "); 
        year = new JTextField(10);
        JPanel yearPanel = new JPanel( new FlowLayout(FlowLayout.LEFT) );  //create panel to hold the label and JTextFields

        //store in panel for year
        yearPanel.add(yearMessage);  
        yearPanel.add(label2); 
        yearPanel.add(year); 
 
        //Authors
        JLabel label3 = new JLabel("  "); 
        authors = new JTextField(30);
        JPanel authorsPanel = new JPanel(); //create panel to hold the label and JTextFields
        JLabel authorsMessage = new JLabel ("Authors: "); 
        
        //store in panel for authors
        authorsPanel.add(authorsMessage); 
        authorsPanel.add(label3);
        authorsPanel.add(authors); 
      
        //Publisher
        JLabel label7 = new JLabel("  "); 
        JLabel publishMessage = new JLabel ("Publisher: ");
        publisher = new JTextField(30);
        JPanel publishPanel = new JPanel(); //create panel to hold the label and JTextFields  
        
        //store in panel for publisher
        publishPanel.add(publishMessage); 
        publishPanel.add(label7);
        publishPanel.add(publisher); 
        
        //Maker
        JLabel label5 = new JLabel ("      ");
        JLabel markerMessage = new JLabel ("Maker: ");
        maker = new JTextField(30); 
        JPanel makerPanel = new JPanel();  //create panel to hold the label and JTextFields 

        //store in panel for maker
        makerPanel.add(markerMessage); 
        makerPanel.add(label5);
        makerPanel.add(maker); 
      
        JPanel messJPanel = new JPanel (new FlowLayout(FlowLayout.LEFT)); 
        JLabel message = new JLabel ("Messages");
        messJPanel.add(message); 

        messageArea = new JTextArea(10,15);
        messageArea.setLineWrap(true);
        messageArea.setEditable(false);
    
       JScrollPane messagesScroll = new JScrollPane(messageArea);  //store message JTextArea in ScrollPane


        //add all panels to firsthalf
        firstHalf.add(add);
        firstHalf.add(productStriPanel);
        firstHalf.add(product); 
        firstHalf.add(descriptionPanel); 
        firstHalf.add(pricePanel); 
        firstHalf.add(yearPanel); 
        firstHalf.add(authorsPanel); 
        firstHalf.add(publishPanel); 
        firstHalf.add(makerPanel);
        firstHalf.add(messJPanel);

        //  button
        JPanel buttonPanel = new JPanel (); 
        BoxLayout layout = new BoxLayout(buttonPanel, BoxLayout.Y_AXIS); 
        buttonPanel.setLayout(layout); //Panel to hold button

        JButton resetButton = new JButton("Reset"); //reset button
        resetButton. addActionListener(new ResetListener());

        JButton addButton = new JButton("Add");  //add button
        addButton. addActionListener(new AddButtonListener());

        JPanel c = new JPanel ();  //placeholders
        JPanel d = new JPanel ();  //placeholders

        //add buttons to panel
        buttonPanel.add(resetButton); 
        buttonPanel.add(c); 
        buttonPanel.add(d); 
        buttonPanel.add(addButton); 
  
    
        JPanel a = new JPanel ();   //placeholders

        secondHalf.add(a);
        secondHalf.add(buttonPanel);  //add buttons (which are in a Panel) to second Half Panel

        secondHalf.add(buttonPanel); 

        //add everything to the the "add" panel
        addPanel.add(firstHalf, BorderLayout.LINE_START);  
        addPanel.add(messagesScroll, BorderLayout.PAGE_END); 
        addPanel.add(secondHalf, BorderLayout.CENTER); 
    }

    public void search () {
        JPanel firstHalf = new JPanel ();  //panel to hold panel for search (labels + textfields)
        JPanel secondHalf = new JPanel (new GridLayout(3, 0)); //panel to store panel of button 
        BoxLayout firsLayout = new BoxLayout(firstHalf,BoxLayout.Y_AXIS);
        firstHalf.setLayout(firsLayout);


        JLabel addMessageText = new JLabel ("Searching products "); 
        firstHalf.add(addMessageText);

        JPanel addMessagePanel = new JPanel( new FlowLayout(FlowLayout.LEFT)); 
        addMessagePanel.add(addMessageText); 
      
     
        firstHalf.add(addMessagePanel);
        
        //productId
        JLabel productMessage = new JLabel ("ProductID: ");
        productId2 = new JTextField(30);
        JPanel product = new JPanel();  //create panel to hold the label and JTextFields 

        //store in Panel for productID
        product.add(productMessage);
        product.add(productId2); 


        firstHalf.add(product);  //add to frist half 
      
        //Keywords
        JLabel keywordLabel = new JLabel("Keywords: ");
        description2 = new JTextField(30);
        JPanel descriptionPanel = new JPanel();  //create panel to hold the label and JTextFields 
         
        //store in Panel for keyword
        descriptionPanel.add(keywordLabel);
        descriptionPanel.add(description2); 
      
        firstHalf.add(descriptionPanel); //add to firstHalf
         
        //Start Year
        JLabel yearMessage = new JLabel ("Start Year: "); 
        sYear = new JTextField(30);
        JPanel yearPanel = new JPanel();  //create panel to hold the label and JTextFields 

        //store in panel for start year
        yearPanel.add(yearMessage); 
        yearPanel.add(sYear); 

        firstHalf.add(yearPanel);  //add to first Half

        JLabel yearMessage2 = new JLabel ("End Year: ");  
        eYear = new JTextField(30);
        JPanel yearPanel2 = new JPanel();  //create panel to hold the label and JTextFields 

         //store in panel for end year
        yearPanel2.add(yearMessage2); 
        yearPanel2.add(eYear); 

        firstHalf.add(yearPanel2);  //add to first Half
        
        JPanel messJPanel = new JPanel (new FlowLayout(FlowLayout.LEFT));  //create panel to hold the label and JTextFields 
        JLabel message = new JLabel ("Search Results");
        messJPanel.add(message); // store in Panel for Search Results
        firstHalf.add(messJPanel); //add to first Half

        searchResults = new JTextArea(10,15);
        searchResults.setLineWrap(true);
        searchResults.setEditable(false);

        JScrollPane messagesScroll = new JScrollPane(searchResults); 

        //  button Panel 
        JPanel buttonPanel = new JPanel (); 
        BoxLayout layout = new BoxLayout(buttonPanel, BoxLayout.Y_AXIS);
        buttonPanel.setLayout(layout);

        //button to reset search fields
        JButton resetButton = new JButton("Reset");
        resetButton. addActionListener(new ResetSearchListener()); 
        buttonPanel.add(resetButton); 

        //button to perform search 
        JButton searchButton = new JButton("Search"); 
        searchButton. addActionListener(new SearchButtonListener());
        buttonPanel.add(searchButton); 
        JPanel c = new JPanel ();  //placeholders
        JPanel d = new JPanel ();  //placeholders

        //add buttons to panel
        buttonPanel.add(resetButton); 
        buttonPanel.add(c); 
        buttonPanel.add(d); 
        buttonPanel.add(searchButton); 
  
    
        JPanel a = new JPanel ();   //placeholders

        secondHalf.add(a); 
        secondHalf.add(buttonPanel); 

        //add everything to the the "search" panel
        searchPanel.add(firstHalf, BorderLayout.LINE_START);
        searchPanel.add(messagesScroll, BorderLayout.PAGE_END);  
        searchPanel.add(secondHalf,BorderLayout.CENTER); 
    }


}
