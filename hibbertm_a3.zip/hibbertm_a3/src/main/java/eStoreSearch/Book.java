package eStoreSearch;
import java.util.Scanner; //to scan data from keyboard
import java.util.*; 
import java.util.regex.Matcher; 


public class Book extends Product { //subclass of item

    private String author = null; 
    private String publisher = null; 

    Scanner inputAuthor = new Scanner (System.in); 
    Scanner inputPublisher = new Scanner (System.in); 
     

    /**
     * copy constructor
     * @param book 
     */
    public Book (Book book) {
       super(book); 
       this.author = book.getAuthor();
       this.publisher = book.getPublisher(); 
    }
   /** 
    * constructor 
    */
    public Book () {
       super (); 
    }
     /**
      * This constructor used for Junit testing (so no user input)
      */
     public Book (String productID, String descrip, String price, String year, String authors, String publisher, ArrayList <Product> productList ) throws InvalidInputException { // t
        super(); //calls the super class contructor that is used for testing
        if (setProductID(productID) == false) throw new InvalidInputException("Invalid Input for productId! Must be integer value of length 6. (required) "); 
        if (setDescription(descrip) == false)  throw new InvalidInputException("Invalid Input for description! Must not be left empty "); 
        if (setPrice(price) == false) throw new InvalidInputException("Invalid Input for price! Must be a valid price");
        if (setYear(year) == false) throw new InvalidInputException("Invalid Input for year! Must not be left empty and must be between 1000-9999 ");;
        EStoreSearch check = new EStoreSearch (new ArrayList <Product> (productList));
        check.productIdCheck(getProductID());
        setAuthor(authors);
        setPublisher(publisher);
        if (check.productIdCheck(getProductID()) == true)  throw new InvalidInputException("Duplicate product");
     }

     public Book getBook (Book book) {
        return new Book(book); 
     }

   
    
    public void setAuthor (String author) {   
       this.author = author;
    } 

    public String getAuthor () {  
       return author; 
    }

    public void setPublisher (String publisher) {
       this.publisher = publisher; 
    }

    public String getPublisher () {
       return publisher;   
    }

    @Override
    public String toString () {
        return  (super.toString()+ getAuthor() + "\n" + getPublisher());
    }
    @Override 
    public String fileToString () {
      return super.fileToString() + "authors = " + "\""+ getAuthor()+ "\"" + "\n" + "publisher = " + "\""+ getPublisher()+ "\""; 
   }
    @Override
    public boolean equals (Object aObject) {
      if (super.equals(aObject) == false) return false;
      if (this.getClass() != aObject.getClass())
         return false;
      Book aBook = (Book) aObject;
      return (this.author.equals(aBook.author) && this.publisher.equals(aBook.publisher));
    }

    
} //end of Book class
