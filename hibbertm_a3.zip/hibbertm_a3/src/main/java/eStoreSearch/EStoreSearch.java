package eStoreSearch;

import java.util.HashMap;
import java.util.*; 

public class EStoreSearch extends SetSearch {

    private ArrayList<Product> productList; // create array list of the object Product
    ArrayList<Product>listOfFound = new ArrayList<Product>(); //Stores the products when found in a search
    ArrayList<Integer >intersectionList = new ArrayList <Integer> ();   //used in keywords search -> holds the intersection of the keyword Search
             
    public EStoreSearch (String productId, String keywords, String year,ArrayList<Product> productList) throws InvalidInputException {
        setKeyword(keywords); 
        if (setYear(year) == false) throw new InvalidInputException("Invalid Input for year"); 
        if (setProductID(productId) == false) throw new InvalidInputException("Invalid Input for productId");
        this.productList = new ArrayList <Product> (productList); 
    }

    public EStoreSearch ( ArrayList<Product> productList) {  
        super(); 
        this.productList = new ArrayList <Product> (productList); 
    }
      
    public ArrayList<Product> getProductList() {
        return new ArrayList <Product> (productList);
    }
 
    /**
     * 
     * @param productList Array List in Book
     * @return the number of items found, if not item return 0, of user input for search is empty, return -1
     */
    public int search () {
        if(getProductID().isEmpty() == true && getKeyword().isEmpty() == true && getYear().isEmpty() == true) return -1; 
           
           if (getKeyword().isEmpty() == false) { //if user inputted keyword        
                mappingKeywords(); //create hashmaps of keywords and map to integer List of matches description word from productList index
                                    // and find intersection and store in intersectionList
                searchKeywords();
           }
        
            if (getProductID().isEmpty() == false) { // if user inputted productId
                searchProductID(); 
            }

            if (getYear().isEmpty() == false) {  //if user inputted year
                searchYear();
            }

        if (productList.size() == 0) return 0;  //if they are no matches return 0
        

        return (productList.size());  //matches were found and is returning the number of mathces found
    } //end of search

    /**
     * search productID
     */
    private void searchProductID ()  {
        Iterator <Product> iterator = productList.iterator();

        while (iterator.hasNext()) {
            Product product = iterator.next(); 
            if (getProductID().equals(product.getProductID()) == false) { //if it doesn't match user input to search for remove from list
                iterator.remove(); 
            }
        }
    } //end of searchProductID

    /**
     * Search Keywords
     */                 
    private void searchKeywords ()  {

        ArrayList<Product>listOfFound = new ArrayList<Product>();
        for (int i = 0; i < intersectionList.size(); i++) { 
            int index = intersectionList.get(i).intValue(); 
            listOfFound.add(productList.get(index));  
        }
        
        optimizeSearch(listOfFound); //optimizeSearch by making product at the intersection be in productList

    } // end of searchkeyword
   
    /**
     * used to create the list of words that match the keywords (if inputted)
     * @param listOfFound 
     */
    private void optimizeSearch (ArrayList <Product> listOfFound) {
        productList.removeAll(productList);   
        for (Product product: listOfFound) {
            productList.add(product); 
        }
    }

    /**
     * Find the index of the products that match the first keyword and map the keyword to ArrayList of Integer
     */
    public void mappingKeywords() {
        String [] keyword  = getKeyword().split("[ ]+"); //split keywords 
        HashMap <String, ArrayList<Integer> > matches = new HashMap <String, ArrayList<Integer> >();  //String = keyword
                                                           //ArrayList of Integer = index of products matches to keywords
                                                         //The ArrayList of each keywords is determined by the intersection of the previous added
        for (int i = 0; i < keyword.length; i ++) {
            keyword[i] = keyword[i].toLowerCase(); 
            ArrayList<Integer >indexOfFound = arrayMatches(keyword[i]); 
            matches.put(keyword[i], indexOfFound); 
        }
        if (matches.size() > 1) { //if more than on keyword was provided then find intersection
            intersection(keyword, matches);
        } else { // then only one keyword was provided so intersectionList is equal to the value of the keyword[0]
            intersectionList = matches.get(keyword[0]); 
        }
    }

    /**
     * Find the intersection of index for the keywords
     * @param keyword is an array of keywords
     * @param matches HashMaps of Keywords
     */
    public void intersection(String [] keyword, HashMap <String, ArrayList <Integer>> matches) {

        ArrayList <Integer> indexOf1 = matches.get(keyword[0]); //get initial ArrayList of words
        for (int i = 1; i < keyword.length; i++) {
            ArrayList <Integer> indexOf2 =  matches.get(keyword[i]); //get ArrayList of words
            ArrayList<Integer>intersectArrayList = new ArrayList<Integer>();  //store array list of intersection

            for (int num1 : indexOf1) {
                for (int num2 : indexOf2) {
                    if (num1 == num2 ) {   //if they "intersect then it's a match"
                        intersectArrayList.add(num1); 
                    }
                }
            }
            indexOf1 = intersectArrayList;
            intersectionList = intersectArrayList; //set intersectionList (instance variable of this class) that holds interection of integers 
        } 
    }

    /**
     * 
     * @param keyword a word (we got from user to search for)
     * @return ArrayList of Integers that holds index of matched products from product List
     */
    public ArrayList arrayMatches  (String keyword) {
        ArrayList<Integer>indexOfFound = new ArrayList<Integer>();

        for (int i = 0; i < productList.size(); i++) {
            if (isMatch(keyword, productList.get(i).getDescription()) == true) {
               indexOfFound.add(i);    
            }
        }
        return indexOfFound; 
    }
    /**
     * 
     * @param keyword a word (provided by user to search for)
     * @param description a word/words 
     * @return true if a keyword in found in description
     */
    private boolean isMatch (String keyword, String description) {
        
        String [] d; //keep track of the matches of keyword in description 
        int j = 0; 

        d = description.split("[ ]+"); //gets words in description and store in String []

            for(j = 0; j < d.length; j++) { //iterates through each description for each keywords 
                if (d[j].equalsIgnoreCase(keyword)) { // if word in description matches keyword then increase match
                    return true; 
                }
            }//end of inner loop
        return false;   
    }


    /**
     * outer methods to search for yYear
     */
    private void searchYear () {
       
        String year = getYear(); //user input for time period

        if (year.length() == 4) {
            searchListYear(1); //compare and store data in Lists if format of time period is year only
        } //end of year only
                
        if (year.length() == 5) {
            searchListYear(2); //compare and store data in Lists if format of time period is  -year || year-
        } //end of -year || year-
                
        if (year.length() == 9) {
            searchListYear(3); //compare and store data in Lists if format of time period is year-year
        } //end of year-year

    } 
    /**
     * check if List are empty of not and call the method it needs absed on that to search for year
     * @param yearFormat if the year if year only (1), year- / -year (2), year - year (3)
     */
    private boolean searchListYear (int yearFormat)  {
        //addlistOfFoundYear(yearFormat);
        Iterator <Product> iterator = productList.iterator(); 
        while  (iterator.hasNext()) {   
            Product product = iterator.next(); 
            if (yearFormat == 1) { //year Only 
                if ( oneTimeMatch(product.getYear()) == false) { //if year matches in year in Book 
                    iterator.remove();
                }
            }
            if (yearFormat == 2) { //year -year or year-
                if ( twoTimeMatch( product.getYear()) == false) { //if year matches in year in Book 
                    iterator.remove(); 
                }
            }
            if (yearFormat == 3) { //year-year
                if ( threeTimeMatch( product.getYear()) == false) { //if year matches in year in Book 
                    iterator.remove();
                }    
            }
        }
        if (productList.isEmpty()) return false; 
        return true; 

    } //end of timeLengthOne

    /**
     * This function compares user input search to year -> This is only if the year format is year Only
     * @param year year to compare with user input year
     * @return true if it's match
     */
    public boolean oneTimeMatch (String year) {
        if(this.getYear().equalsIgnoreCase(year) == true) return true; //year is match 
        return false; 
    } //end of oneTimeMatch 
   
    /**
     * This function compares user input search to year -> This is only if the year format is Year- and -Year
     * @param year year to compare with user input year
     * @return true if it's a match
     */
    public boolean twoTimeMatch (String year) {

       if (this.getYear().charAt(0) == '-') { //if the format is -year
            String [] yearSplit = this.getYear().split("-"); 
            int yearInt = Integer.parseInt(year); 
            int yearSplitInt =  Integer.parseInt(yearSplit[1]); 
          if (yearInt <= yearSplitInt) return true; //if year is in period -year then return true
       } else { //else format is year -
            String [] yearSplit = this.getYear().split("[- ]+"); 
            int yearInt = Integer.parseInt(year); 
            int yearSplitInt =  Integer.parseInt(yearSplit[0]); 
        if (yearInt >= yearSplitInt) return true; //if year is in period year- then return true
      }
        return false; 
    } //end of twoTimeMatch 

    /**
     * This function compares user input search to year -> This is only if the year format is Year-Year
     * @param year year to compare with user input year
     * @return true if it's a match
     */
    public boolean threeTimeMatch (String year) {
        String [] yearSplit = this.getYear().split("-"); //split format year - year 
        int firstYear = Integer.parseInt(yearSplit[0]); 
        int secondYear = Integer.parseInt(yearSplit[1]);
        int yearInt = Integer.parseInt(year);

        if (yearInt >= firstYear && yearInt <= secondYear) return true; //if year is between period year-year inclusive then return true
        return false; 
    }

  
    /**
     * boolean method : search if input productID or one we already have match 
     * this methods determins if we add the object or not
     * @param productIdInput  user input for productid from item class
     * @return true if input productID and bookList productId is a match
     */
    public boolean productIdCheck(String productIdInput)  {
        boolean matchOrNot = false; 
        String productId;
        int i = 0; 
        if (productList.isEmpty() == true) return false; 
        for (i = 0; i < productList.size(); i++) {
              productId = productList.get(i).getProductID(); 
             if (productId.equals(productIdInput)== true) {
                 return true; 
             }
        }
        return  matchOrNot; 
     }    //in main if productIdCheck is true then don't add

     /**
      * This return a copy of the intersection List
      */
     public ArrayList<Integer> getIntersectionList() {
         return new ArrayList <Integer>(intersectionList);
     }


} //end of eStoreSearch 