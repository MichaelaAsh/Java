package eStoreSearch; 
import java.util.Scanner;
import java.util.*; 

public abstract class Product { //abstract class -> only can be accessed through concrete class 

    public static final int MAX_LENGTH_PID = 6;
    public static final int MAX_LENGTH_YEAR = 4; 

    String productID = null; 
    String description = null; 
    private double price; 
    private String year = null; 

    Scanner inputProductID = new Scanner (System.in); 
    Scanner inputDescription = new Scanner (System.in); 
    Scanner inputPrice = new Scanner (System.in); 
    Scanner inputYear = new Scanner (System.in);

    /**
     * constructor 
    */
    public Product () {
        
    }
   
    /**
     * Copy constructor
     * @param product takes in a product
     */
    public Product (Product product) {
        this.productID = product.getProductID(); 
        this.description = product.getDescription();
        this.price = product.getPrice(); 
        this.year = product.getYear();
    }

   /**
    * 
    * @param productID from user input 
    * @return true if product is Valid
    */
    public boolean setProductID (String productID) {
    
        if (productID.isBlank() == true) return false; //user must enter a productId or return false
    
         if (productID.isEmpty() == false) { 
            String [] trimP = productID.split ("[ ]+"); 
             this.productID = trimP[0]; 

             if (this.productID.matches("[0-9]+") && this.productID.length() == MAX_LENGTH_PID ) {
                 this.productID = productID; 
                 return true ;   //if user inputted data and it's a 6 digits number  return true
              }
         }
         System.out.println(); 
         //System.out.println("Error: Not Integer value or length != 6. ");
         return false;    

     }     
    
    public String getProductID () {
        return productID; 
    }

    /**
     * 
     * @param description from user input
     * @return true if valid
     */
    public boolean setDescription  (String description) {  
            
        if (description.isEmpty() == true || description.isBlank() == true) return false; 
        if (description.isEmpty() == false) { //is user inputed description, exit loop
            this.description = description; 
            return true; 
        }
        return false; 
    }
    /**
     * 
     * @return description
     */
    public String getDescription  () {
        return description; 
    }
   /**
    * 
    * @param year from user input
    * @return true if is year is Valid
    */
    private boolean yearErrorCheck (String year) {  //check to see if year is formatted properly based on guidlines 

        if (year.matches("[0-9]+") ) {  //if years are numbers
            if (year.length() >= MAX_LENGTH_YEAR ) { //if year is a 4 digit number
                int m = Integer.parseInt(year); 
                if (m >= 1000 && m <=9999) { //if both years are between 1000 and 9999
                    return false;   //meaning no error in format detected 
                }
            } 
        }
        return true; // there is an error for format of year
    }
    /**
     * 
     * @param year user input
     * @return true if valid
     */
    public boolean setYear (String year) {   
        this.year = year; 
        if (year.isEmpty() == true || year.isBlank() == true) return false; 
    
        if (year.isEmpty() == false) {   
            String [] trimY = year.split("[ ]+"); 
            year = trimY[0]; 
            if ( yearErrorCheck(year) == false ) { //meaning user inputted correct format for the year
                this.year = year; 
                return true; //if user correct Year format, exit loop
            }
        }
        System.out.println();
        return false; 
    }
    
    public String getYear () {  
        return year; 
    }
    /**
     * 
     * @param line user input 
     * @return true if valid 
     */
    public boolean setPrice ( String line) { 

        if (line.isEmpty() == true) return true; //return true if 

        if (line.isEmpty()== false)  {    //in input isn't empty       
            if (line.matches("[0-9]+") == true || line.matches("[0-9]+.[0-9]+") == true) { //if its decimal or integer
                price = Double.parseDouble(line);  
                return true; 
            } else {
                System.out.println();
            }
        } 
           
        return false; 

    } 

    public double getPrice () {   
        return price; 
    } 

    public String toString () {
        return  (getProductID() + "\n" + getDescription() + "\n" + getPrice() + "\n" + getYear() + "\n");
    }
    public String fileToString () {
        return "productID = " + "\""+ getProductID() + "\""+ "\n" + "description = " + "\""+ getDescription() + "\""+ "\n" + "price = " + "\""+ getPrice() + "\""+ "\n" + "year = "+ "\"" + getYear() + "\""+ "\n"; 
    }
    public boolean equals (Object aObject) {
        if (aObject == null) {
            return false; 
        } else if (getClass() != aObject.getClass()){
            return false; 
        } else {
            Product aProduct = (Product)aObject; 
            return (productID.equals(aProduct.productID) && description.equals(aProduct.description) && year.equals(aProduct.year) );
        }
    }

} //end of Item class


