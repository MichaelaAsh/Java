package eStoreSearch;

import java.util.ArrayList;
import java.util.Scanner;

import java.io.File; 

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;

public class FileIO {
    private String type = null; 
    private String productID = null; 
    private String description = null; 
    private String year = null; 
    private String price = " "; 
    private String maker = " ";  
    private String author = " "; 
    private String publisher = " "; 
    
    private ArrayList<Product> productList; // create array list of the object Product

    public FileIO (ArrayList <Product> productList){
        this.productList = new ArrayList <Product> (productList); 
    }
    public ArrayList<Product> getProductList() {
        return new ArrayList <Product> (productList);
    }

    /**
     * this function is to read from a file and store in list (each line)
     * @return Arraylist of products loaded from files
     */
    public void loadFile (String fileName) {
        
        try { 

            Scanner input = new Scanner (new FileInputStream(fileName)); // read in file
            readFile(input); 
        } catch (Exception e) {
            System.out.println ("\nError: Could not open file\n");
            System.exit(0);
        }

    }

     /**
     * 
     * @param input is the line for the file   
     * @param productList is the list that stores object after reading and setting. 
     */
    private void readFile (Scanner input) { 
        int i = 0;
        boolean shouldRestart = false; 
        while (input.hasNextLine()) {
            String inputStrings = input.nextLine(); 
            readProduct(inputStrings, i); //read the string in for product
            if (type.equals("book")) {
                shouldRestart =  readBook(inputStrings, i); //read the string for book -> publisher and authors
                if (shouldRestart == true) { //if it's true then end of reading  product
                    Book book = makeBook(); 
                    productList.add(book); 
                } 
            } else if (type.equals("electronics")) {
                if (i == 5) {
                    shouldRestart =readElectronics(inputStrings);  //read the string in for electronics -> maker
                    if (shouldRestart == true) { //if it's true then end of reading  product
                        Electronics electronics = makeElectronics(); 
                        productList.add(electronics); 
                    } 
                }
            }
            if (shouldRestart == true) {
               i = 0; 
               shouldRestart = false;
            } else {
                i++; 
            }
        }
    }
     /**
     * this function reads to files
     * @param productList is the info that is used to write to file.txt
     */
    public void saveFile (String file) throws InvalidInputException {
        try {
          //  System.out.println("HELLO");
            File tempFile = new File (file); //if this file already exists
            tempFile.delete();                      //then delete it cause we want to "rewrite file"
           
            for (int i = 0; i < productList.size(); i++) { // iterate through student List
                PrintWriter fileWriter = new PrintWriter (new FileOutputStream(file, true)); //open files to write. true b/c appending to list
                boolean isBook = Book.class.isInstance(productList.get(i));
                boolean isElectronics = Electronics.class.isInstance(productList.get(i));
              
                if (isBook == true ) {
                    String type  = "type = \"book\"\n"; 
                    String product = type + productList.get(i).fileToString(); 
                    fileWriter.println(product); 
               } 
                if (isElectronics == true) {
                    String type  = "type = \"electronics\"\n"; 
                    String product = type + productList.get(i).fileToString(); 
                    fileWriter.println(product); 
                }
                //fileWriter.println(productList.get(i).toString(true)); //write to list on each list
                fileWriter.close();       //dont't need to close -> java automatically closes list       
            }
            System.out.println ("Products successfully written to " + file); 
            productList.removeAll(productList); //remove all elements in List
            System.out.println(); 
        } catch (Exception e) {
            throw new InvalidInputException("Error: Could not write to file");
        }
    }
   /**
    * 
    * @param inputStrings is a line from a file
    * @param i is the line number in reference to reading in a product 
    */
    public void readProduct( String  inputStrings, int i) {
        if (i == 0) {
            String temp1 = inputStrings.replace( "type = ",""); 
            String temp2 = temp1.replace( "\"",""); 
            type = temp2; 
            //System.out.println(type); 
         }
         if (i == 1) {
            String temp1 = inputStrings.replace( "productID = ",""); 
            String temp2 = temp1.replace( "\"",""); 
            productID = temp2;
           // System.out.println(productID); 
         }
         if (i == 2) {
            String temp1 = inputStrings.replace( "description = ",""); 
            String temp2 =  temp1.replaceAll("^\"+|\"+$", "");
            String temp3 = temp2.replace( "\\", ""); 
            description = temp3;
           // System.out.println(description); 
         }   
         if (i == 3) {
             String temp1 = inputStrings.replace( "price = ",""); 
             String temp2 = temp1.replace( "\"",""); 
             price = temp2;
            // System.out.println(price); 
         }
         if (i == 4) {
            String temp1 = inputStrings.replace( "year = ",""); 
            String temp2 = temp1.replace( "\"",""); 
            year = temp2;
           // System.out.println(year); 
        }
    }
    /**
     * 
     * @param inputStrings is a line from a file 
     * @param i is the line number in reference to reading in a product
     * @return true if it's the last thing to read for this product -> which is publisher
     */
    public boolean readBook (String  inputStrings, int i) {
        if (i == 5) {
            String temp1 = inputStrings.replace( "authors = ",""); 
            String temp2 = temp1.replace( "\"",""); 
            author = temp2;
            return false; 
        }
        if (i == 6) {
            String temp1 = inputStrings.replace( "publisher = ",""); 
            String temp2 = temp1.replace( "\"",""); 
            publisher = temp2;
            return true;
        }
      
        return false; 
    }
    /**
     * 
     * @param inputStrings is a line from a file
     * @return true b/c this is the last variable to create an electronics
     */
    public boolean readElectronics (String  inputStrings) {
            String temp1 = inputStrings.replace( "maker = ",""); 
            String temp2 = temp1.replace( "\"",""); 
            maker = temp2;
            return true;
    }
    /**
     * Create a new book and set instance variables 
     * @return book 
     */
    private Book makeBook () {
       Book book = new Book(); 
       book.setProductID(productID); 
       book.setDescription(description); 
       book.setYear(year); 

       book.setPrice(price); 
       book.setPublisher(publisher);
       book.setAuthor(author);
       
       return book; 
    }
    /**
     * Create a new electronics and set instance variables 
     * @return electronics
     */
    private Electronics makeElectronics () {
        Electronics electronics = new Electronics ();
        electronics.setProductID(productID); 
        electronics.setDescription(description); 
        electronics.setYear(year); 
 
        electronics.setPrice(price); 
        electronics.setMaker(maker);

        return electronics; 
    }
    
}