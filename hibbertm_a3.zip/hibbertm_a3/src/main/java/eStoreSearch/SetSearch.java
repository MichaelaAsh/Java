package eStoreSearch;
import java.util.Scanner;

public abstract class SetSearch {

    public static final int MAX_LENGTH_PID = 6;
    public static final int MAX_LENGTH_YEAR = 4; 

    private String productID = null; 
    private  String keyword = null; 
    private  String year = null;; 

    /**
     * set productId
     * @param productId user input
     * @return true if user inout is Valid
     */
    public boolean setProductID (String productId) {
        this.productID = productId; 
        
        if (productID.isBlank() == false) { //is user inputed description, exit loop
           
            if(productID.matches("[0-9]+") && productID.length() == MAX_LENGTH_PID ) { 
                return true; 
            }
        } else if (productID.isEmpty() == true) {
            return true; 
        }
        System.out.println("Error: Not Integer value or length != 6. ");
        return false;
    }  
  
     public String getProductID() {
         return productID; 
     }
    
     /** 
      * set keyword
      * @param keyword user input
      * @return true if user input is Valid
      */
     public boolean setKeyword  (String keyword) {
        this.keyword = keyword; 
        if (keyword.isBlank() == true) {
            return true; 
        }
        return true; 
     }
 
     public String getKeyword () {
         return keyword; 
     }

     /**
     * Error check for year input
     * @param year user input
     * @return true if year input is Valid
     */
    private boolean yearErrorCheck (String year) {  //check to see if year is formatted properly based on guidlines 
        String [] line = year.split("-");  
        if (line.length == 2) { //year - year
            if (line[0].matches("[0-9]+") && line[1].matches("[0-9]+")  ) { //if years are numbers
                                   
                if (line[0].length() == MAX_LENGTH_YEAR &&line[1].length() == MAX_LENGTH_YEAR) {
                    int m = Integer.parseInt(line[0]); 
                    int n = Integer.parseInt(line[1]);
                    
                    if (n >= 1000 && n <= 9999 && m >= 1000 && m <=9999 && m < n) { //if both years are between 1000 and 9999
                        return true;  //meaning no error in format detected 
                    }
                }
            } else { // -year format
                if (line[1].matches("[0-9]+") ) {  //if years are numbers
                    if (line[1].length() == MAX_LENGTH_YEAR ) {
                        int m = Integer.parseInt(line[1]); 
                        if (m >= 1000 && m <=9999) { //if year is between 1000 and 9999
                            return true;  //meaning no error in format detected   
                        }
                    }
                 }  
            }

        } else if (line.length == 1){ // year format
            if (line[0].matches("[0-9]+") ) {  //if years are numbers
                if (line[0].length() == MAX_LENGTH_YEAR ) {
                    int m = Integer.parseInt(line[0]); 
                    if (m >= 1000 && m <=9999) { //if both years are between 1000 and 9999
                        return true;   //meaning no error in format detected 
                    }
                } 
            } 
        } 

        return false; // there is an error for format of year
   }
     
  /**
   * set year
   * @param year user input
   * @return true if input is Valid
   */
   public boolean setYear (String year) {       
       this.year = year;  
       if (year.isEmpty() == true) return true; 
        if (year.isEmpty() == false) {   
            if ( yearErrorCheck(year) == true ) { //meaning user inputted correct format for the year
                return true; //if user correct Year format, exit loop
            }
        }  
        if (year.isBlank() == true) return true; 
        return false; 
    }
   
    public String getYear () {  
       return year; 
    }

} //end of eStoreSearch
