package eStoreSearch;
import java.util.Scanner; //to scan data from keyboard
import java.util.*; 

public class Electronics extends Product {

    private String marker = null; 
    Scanner inputMarker = new Scanner (System.in); 
    
    /**
     * Copy constructor 
     */
    public Electronics (Electronics electronics) {
        super(electronics); 
        this.marker = electronics.getMarker(); 
    }
    /**
     * Copy contructor
     */
    public Electronics() { 
        super(); //calls the super class contructor that is used for testing
    }

    public Electronics (String productID, String descrip, String price, String year, String  maker ,  ArrayList <Product> productList) throws InvalidInputException {

        if (setProductID(productID) == false) throw new InvalidInputException("Invalid Input for productId! Must be integer value of length 6. (required) "); 
        if (setDescription(descrip) == false)  throw new InvalidInputException("Invalid Input for description! Must not be left empty "); 
        if (setPrice(price) == false) throw new InvalidInputException("Invalid Input for price! Must be a valid price");
        if (setYear(year) == false) throw new InvalidInputException("Invalid Input for year! Must not be left empty and must be between 1000-9999 ");
        EStoreSearch check = new EStoreSearch ( new ArrayList <Product> (productList));
        if (check.productIdCheck(getProductID()) == true ) throw new InvalidInputException("Duplicate product");
        setMaker(maker);
    }
   
    /**
     * 
     * @param electronics
     * @return a copy of electronics
     */
    public Electronics getElectronics(Electronics electronics) {
        return new Electronics(electronics);
    }

    public void setMaker (String marker) {
        this.marker = marker;    
    }

    public String getMarker () {
        return marker; 
    }
    @Override
    public String toString () {
        return  super.toString() + getMarker();
    }
    @Override 
    public String fileToString () {
      return super.fileToString() + "maker = " +"\""+ getMarker()+ "\""; 
   }

    @Override
    public boolean equals (Object aObject) {
      if (super.equals(aObject) == false) return false;
      if (this.getClass() != aObject.getClass())
         return false;
      Electronics aElectronics = (Electronics) aObject;
      return (this.marker.equals(aElectronics.marker));
    }
    
} //end of Electronics class 
