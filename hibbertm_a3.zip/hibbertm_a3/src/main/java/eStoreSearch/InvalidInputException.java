package eStoreSearch; 
public class InvalidInputException extends Exception {
   
    /**
     * Constructor
     */
    public InvalidInputException  ()  {
        super ("Required Input!"); 
    }
    /**
     * Constructor
     * @param message
     */
    public InvalidInputException  (String message) {
       super (message); 
    }

}

