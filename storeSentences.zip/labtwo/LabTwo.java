package labtwo;

import java.util.Scanner; //to scan data from keyboard
public class LabTwo {

    public static int numberCharacters(String[] string, int index) { //return the number of charcters in a String[]
        int i; 
        int count = 0;  
        for (i = 0; i < index; i++) {
            count = count + string[i].length(); //count the character found on each line/index
        } 
        return count; 
    }
    public static int numberVowels (String [] string, int index) { // returns the numebr of voels in a String []
        int j = 0;
        int k = 0; 
        int count = 0; 
        for (k = 0; k < index; k++) {
            for (j = 0; j < string[k].length() ;j++) { 
                if ( string[k].charAt(j) == 'a' || string[k].charAt(j) == 'e' || string[k].charAt(j) == 'i' || string[k].charAt(j)== 'o' || string[k].charAt(j) == 'u') {
                    count++; //counting occurence of vowel
                }
            }
         }
        return count; 
    }
    public static String wordSearch (String[] string, String stringToSearch, int index, boolean caseSensitive) { //seach for word in a String []. Does case senstive or case Insentive Seach
        String [] result;                                                                                        //return a String that says been found or not been found
        String foundORNOT = "not been found"; 
        boolean check = false; 
        int i = 0;
        int j = 0; 
        for (i = 0; i < index; i++) {
            result = string[i].split (" ", -1);   //get words in the sentence and stores in String []
            for (j = 0; j < result.length; j++) {
                if (caseSensitive == true) {
                    check = result[j].equals(stringToSearch); //check each word if it's a match (case sensitive)
                } else {
                    check = result[j].equalsIgnoreCase(stringToSearch); 
                }
                if (check  == true)  {
                    foundORNOT = "been found"; 
                } 
            }//end of inner loop
        }  //end of outer loop 
        return foundORNOT;    
    }

    //compare case function 
    public static void main ( String[] args) {
        //allows user to store 10 sentences in array
        Scanner inputOption = new Scanner(System.in); //declare scanner object to take use input 
        Scanner inputWords = new Scanner (System.in); 
        Scanner inputSearch = new Scanner (System.in); 
        String [] words = new String[10];  //only can store 10 sentences 
        int option = 0; //keep tracks of the user choice
        int index = 0;
        int start = 0; //start of word index

        while (option != 9) {
            System.out.println("\n(1) Enter a full sentence."); 
            System.out.println("(2) Print out all sentences entered thus far in the given order."); 
            System.out.println("(3) Print out the number of sentences that have been entered thus far.");
            System.out.println ("(4) Print out all sentences entered thus far in the reverse order."); 
            System.out.println("(5) Print out the number of characters in all sentences combined.");
            System.out.println("(6) Calculate the total number of vowels contained in all stored sentences.");
            System.out.println("(7) Perform search for a given word using case insensitive comparisons.");
            System.out.println("(8) Perform search for a given word using case sensitive comparisons.");
            System.out.println("(9) End program.\n"); 
            System.out.print("Option: "); 
            option = inputOption.nextInt(); 
            System.out.print("\n"); 
            if (option == 1) {
                if (index < 10) { //only can store 10 sentences 
                     words[index] = inputWords.nextLine(); //put sentence into element 
                     index++; 
                } else { 
                    System.out.println("You have reached the maximum sentence you can enter in this program"); 
                }           
            } // end of option 1
            if (option == 2) {
               for (start = 0; start < index; start++) {
                    System.out.println  (words[start]);//print all sentences 
                }
            } //end of option 2

            if (option == 3) {
                System.out.println("Number of sentences: " + index); // print number of sentences entered so far
            } //end of option 3

            if (option == 4) {
                 int end;  
                 for (end = index - 1; end >= 0; end--) {
                    System.out.println  (words[end]); //print sentences in reverse 
                }
            } //end of option 4

            if (option == 5) {
                int count = numberCharacters(words, index); //find the number of character in a String []
                System.out.println("Number of characters: " + count); //print the number of characters in a String []
            }  //end of option 6

            if (option == 6) {
                int count = numberVowels(words, index); //find the number of vowels in a String []
                System.out.println("Number of vowels: " + count); //print the number of vowels in a String []
            } // end of option 6

            if (option == 7) {
                String input = inputSearch.nextLine(); //get user input to find what word to search for
                String foundORNOT = wordSearch(words, input, index, false); //perform case insentive seach 
                System.out.println("The word has " + foundORNOT); // print if the word has been found or Not
            }// end of option 7 

            if (option == 8) {
                String input = inputSearch.nextLine();//get user input to find what word to search for
                String foundORNOT = wordSearch(words, input, index, true); //perform case sensitive search 
                System.out.println("The word has " + foundORNOT); // print if the word has been found or Not
            }// end of option 7 
  
        }//end of loop

        System.out.println("End of program");

    } //end of main
} //end of LabOne class