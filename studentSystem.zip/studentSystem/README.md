## NOTE
When you search the hashMap (command 8), you search like this: programYearLastNAme 
For example if you want to search for : Psych 2 92.1 Brown
You will have to write: Psych2Brown
