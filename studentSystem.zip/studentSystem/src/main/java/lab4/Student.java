package lab4; 
import java.util.Scanner; 

public class Student {

    private String program; 
    private String year =  " "; 
    private double percentage = 0.0; 
    private String lastName; 


    public Student (String [] program, String year, String grade, String name) throws RequiredInputException, InvalidRangeException { //if there is not file, isFile == false and we take input else we dont;
        if (program.length > 1)  throw new RequiredInputException("Invalid format for program! "); 
        if (setProgram(program[0]) == false)  throw new RequiredInputException("No program inputted"); 
        if (setYear(year) == false) throw new RequiredInputException("Invalid year"); 
        if (setPercentage(grade) == false) throw new InvalidRangeException(); //throw if not valid
        if (setLastName(name) == false)  throw new RequiredInputException("No LastName inputted"); //throw if user didn't input a lastName
    }
    
    public Student () {

    }

    public Student (Boolean isFile) throws RequiredInputException, InvalidRangeException { //if there is not file, isFile == false and we take input else we dont;
        if (isFile == false){

            System.out.print("Enter Program and Year: "); 
            Scanner input = new Scanner (System.in); 
            String line = input.nextLine (); 
            String [] splitLine = line.split("[ ]+"); 

            if ( splitLine.length < 2) { //meaning that both Program and/or year has not been ionpuuted
                throw new RequiredInputException(); 
            } 
            
            if (splitLine.length >= 2) { // if user input 2 things or more 
                if (setProgram(splitLine[0]) == false)  throw new RequiredInputException("No program inputted"); 
                if (setYear(splitLine[1]) == false) throw new RequiredInputException("Invalid year"); 
            }

            System.out.print("Enter Average Grade or leave blank: ");  
            Scanner inputGrade = new Scanner (System.in); 
            String grade  =inputGrade.nextLine(); 
            if (setPercentage(grade) == false) throw new InvalidRangeException(); //throw if not valid

            System.out.print("Enter Last Name (required): ");  
            Scanner inputName = new Scanner (System.in); 
            String name  =inputName.nextLine(); 
            if (setLastName(name) == false)  throw new RequiredInputException("No program inputted"); //throw if user didn't input a lastName
           
        }
    }

    public boolean setProgram(String program) { 
        this.program = program;
        if (this.program.isEmpty() == false) return true; //if user did input then return true 
        return false; //if user did not input anything then return false b/c program required 
    }
    public boolean setPercentage(String percentage) {
        if (percentage.isEmpty() == true) return true;  //if user did not input percentage then return true b/c not required
        if (percentage.matches("[0-9]+") == true|| percentage.matches("[0-9]+.[0-9]+") == true) {  //check if the user input was an integer or decima;
            double integer = Double.parseDouble(percentage); 
            if (integer >= 0 && integer <= 100)  { //check if user input peercentage in a valid range, if so set percentage 
                this.percentage = integer; 
                return true; 
            }
         
        }
        return false; //return false if user didn't enter a valid percentage
    }

    public boolean setYear(String year) {
        this.year = year;
        if (year.matches("[0-9]+") == true ) {  //check if input is a integer
            int integer = Integer.parseInt(year);  
            if (integer >= 0) return true;  //if the input is not negtive then it is valid and you can retur
        }
        return false;  //return false if user didn't enter a valid year
    }
    public boolean setLastName(String lastName) {
        this.lastName = lastName;
        if (this.lastName.isEmpty() == false) return true; //if user did input then return true 
        return false; //if user did not input anything then return false b/c program required 
    }

    public String getProgram() {
        return this.program;
    }

    public Double getPercentage() {
        return this.percentage;
    }
    
    public String getYear() {
        return this.year;
    }
    public String getLastName() {
        return lastName;
    }

    public String toString( boolean isFile) {   //return String of instance Variable  
        if (isFile == false ) {
            return "Program: " + getProgram() + "\n" + "Year: " + getYear() + "\n" + "Average Grade: "  + getPercentage() + "\n" +  "Last Name: "  + getLastName() + "\n"; 
        } else {              
            return  getProgram() + " " +  getYear() + " " + getPercentage() + " ";  
        }
    }

    public String toString () {
        return  getProgram() + " " +  getYear() + " " + getPercentage() + " " + getLastName();  
    }


}

