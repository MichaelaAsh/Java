package lab4; 
public class RequiredInputException extends Exception {
   
    public RequiredInputException  ()  {
        super ("Required Input!"); 
    }

    public RequiredInputException  (String message) {
       super (message); 
    }
}

