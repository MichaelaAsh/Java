package lab4; 
import java.util.Scanner; 
import java.util.*; 

public class Search {

    public boolean searchByProgram (ArrayList <Student> studentList) { //performs a search through studentList -> Looking for a program
        int i; 
        int numMatches = 0; 
        Scanner input = new Scanner(System.in); 
        System.out.print("Enter Program to search for: "); //prompt user to input program to search for

        String program = input.nextLine(); 
        for (i = 0; i < studentList.size(); i++) {
            if (program.equalsIgnoreCase(studentList.get(i).getProgram()) ) { //if user input program matches the program at the object at i
                System.out.println(studentList.get(i).toString(false)); //print b/c found
                numMatches++; 
            }
        }
        if (numMatches > 0) return true; //if matches were found then return true

        System.out.println("Not found"); 
        return false; 
    }
    /**
     * add key and value to HashMap
     * @param mapStudent hash maps of Students -> key = program year lastName  and value -> student
     * @param studentList list of students 
     */
    public void addToHashMap (HashMap <String, Student> mapStudent,  ArrayList <Student> studentList) {
        int lastIndex = studentList.size() -1; 
        String key = studentList.get(lastIndex).getProgram() +  studentList.get(lastIndex).getYear() +  studentList.get(lastIndex).getLastName(); 
        key = key.toLowerCase(); 
        Student value = studentList.get(lastIndex); 
    
        mapStudent.put(key,value); 
    }
    /**
     * 
     * @param mapStudent hash maps of Students -> key = program year lastName  and value -> student
     * @param student
     * @return
     */
    public boolean isInHash( HashMap <String, Student> mapStudent, Student student) {

        String key = student.getProgram() +  student.getYear() +  student.getLastName(); 
        key = key.toLowerCase(); 
        if (mapStudent.containsKey(key)) {
            return true; 
        } 
        return false;
    }
    /**
     * add key and value to HashMap
     * @param mapStudent hash maps of Students -> key = program year lastName  and value -> student
     * @param studentList list of students 
     */
    public void addToHashMapforFile (HashMap <String, Student> mapStudent,  ArrayList <Student> studentList) {

        for (Student student : studentList) {
            String key = student.getProgram() +  student.getYear() +  student.getLastName(); 
            Student value = student; 
            key = key.toLowerCase(); 
            mapStudent.put(key,value); 

        }
    }
    
    /**
     * Ask user for key, if key is there then print value 
     * @param mapStudent hash maps of Students -> key = program year lastName  and value -> student
     */
    public String searchByHashMaps (HashMap <String, Student> mapStudent, String key){

        key = key.toLowerCase(); 
        if (mapStudent.containsKey(key)) {
            return (mapStudent.get(key).toString(false)); 
        }
        return "Not Found"; 
    }
  
}