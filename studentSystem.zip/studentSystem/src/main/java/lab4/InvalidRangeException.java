package lab4; 
public class InvalidRangeException extends Exception {
   
    public InvalidRangeException ()  {
        super ("Number not in correct range!"); 
    }

    public  InvalidRangeException (String message) {
       super (message); 
    }
}

