package lab4; 
import java.util.Scanner;

public class GraduateStudent extends Student {

    private String supervisor; //mandatory
    private int isPHD;  //madatory 
    private String undergraduateSchool; 

    public GraduateStudent (String [] program, String year, String grade, String name, String supervisor, String isPhD, String undergrad) throws RequiredInputException, InvalidRangeException { //if there is not file, isFile == false and we take input else we dont;
        super (); 
        if (program.length > 1)  throw new RequiredInputException("Invalid format for program! "); 
        if (setProgram(program[0]) == false)  throw new RequiredInputException("No program inputted"); 
        if (setYear(year) == false) throw new RequiredInputException("Invalid year"); 
        if (setLastName(name) == false)  throw new RequiredInputException("No LastName inputted"); //throw if user didn't input a lastName
        if (setPercentage(grade) == false) throw new InvalidRangeException(); //throw if not valid
        if (setSupervisor(supervisor) == false)  throw new RequiredInputException("Supervisor required");
        if (setPHD(isPhD) == false)  throw new InvalidRangeException("Invalid Input for PhD");   
        setUndergraduateSchoo(undergrad); 
    }

    /**
     * constructor
     */
    public GraduateStudent (Boolean isFile) throws RequiredInputException, InvalidRangeException { //if there is not file, isFile == false and we take input else we dont;
        super(isFile);  
        if (isFile == false) {
            System.out.print("Enter Supervisor: "); 
            Scanner input = new Scanner (System.in); 
            String supervisor = input.nextLine ();
            if (setSupervisor(supervisor) == false)  throw new RequiredInputException("Supervisor required");
            
            System.out.print("Do you have a PhD?\nEnter 1 (true) or 0 (false): "); 
            Scanner inputPhD = new Scanner (System.in); 
            String isIntPHD = inputPhD.nextLine ();
            if (setPHD(isIntPHD) == false)  throw new InvalidRangeException("Invalid Input for PhD");

            System.out.print("Enter UnderGraduate School or leave blank: "); 
            Scanner inputSchool = new Scanner (System.in); 
            String School = inputSchool.nextLine ();
            setUndergraduateSchoo(School); 
        }

    } 
   /**
    * 
    * @param supervisor
    * @return true if not empty
    */
    public boolean setSupervisor(String supervisor) {
        this.supervisor = supervisor;
        if (this.supervisor.isEmpty() == false) return true; //cannot be empty 
        return false; 
    }
    /**
     * 
     * @param isIntPHD a string 
     * @return true if the value is 1 or 0
     */
    public boolean setPHD(String isIntPHD) {
        if (isIntPHD.matches("[0-9]+") == true|| isIntPHD.matches("[0-9]+.[0-9]+") == true)  { //check if it's a number 
            int num = Integer.parseInt(isIntPHD);
            if (num == 1 || num == 0) { //must be 1 or 0 for true or false
                this.isPHD = num;
                return true; 
            } else {
                return false; 
            }
        } 
        return false; 
    }

    public int getPHD () {
        return isPHD; 
    }
    
    public String getSuperviser() {
        return supervisor;
    }

    public void setUndergraduateSchoo (String undergraduateSchool) {
        this.undergraduateSchool = undergraduateSchool;
        if (this.undergraduateSchool.isEmpty() == true) {
            this.undergraduateSchool = "N/A"; 
        }
       
    }

    public String getUndergraduateSchool() {
        return undergraduateSchool;
    }

    @Override
    public String toString (boolean isFile) {
        if (isFile == false) {
            String degree; 
           if (isPHD == 1) {
              degree = "PhD"; 
           } else {
               degree = "Masters"; 
           }
            return super.toString(false) + "Supervisor: " + supervisor + "\n" + "Degree: " + degree + "\n" + "Undergraduated School: "  + undergraduateSchool + "\n"; 
        } else {
            return  super.toString(true) + supervisor + " " + isPHD + " " + undergraduateSchool + " " + getLastName(); 
        }
    }
    
    @Override 
    public String toString () {
        return  getProgram() + " " +  getYear() + " " + getPercentage() + " " + supervisor + " " + isPHD + " " + undergraduateSchool + " " + getLastName();  
    }

} // end of class
